<?php
/*
Plugin Name: GOMO Dynamic Schemas
Description: Adds dynamic organization, product, website, blog/article schemas to your website.
Version: 1.0
Author: Anurag Deokar
*/

// Include the necessary files
require_once plugin_dir_path(__FILE__) . 'includes/settings.php';
require_once plugin_dir_path(__FILE__) . 'admin/admin.php';
require_once plugin_dir_path(__FILE__) . 'public/public.php';
require_once plugin_dir_path(__FILE__) . 'includes/submenu-pages.php';
require_once plugin_dir_path(__FILE__) . 'includes/manage-organization.php';
require_once plugin_dir_path(__FILE__) . 'includes/manage-product.php';
// require_once plugin_dir_path(__FILE__) . 'includes/manage-website.php';
require_once plugin_dir_path(__FILE__) . 'includes/manage-blog-post.php';
require_once plugin_dir_path(__FILE__) . 'includes/manage-article.php';
require_once plugin_dir_path(__FILE__) . 'includes/manage-news-article.php';
require_once(plugin_dir_path(__FILE__) . 'includes/manage-faq-schema.php');

// Enqueue custom CSS for the enable/disable schema page
function dynamic_schemas_enqueue_admin_css()
{
    $current_screen = get_current_screen();
    if ($current_screen && $current_screen->id === 'toplevel_page_dynamic-schemas') {
        wp_enqueue_style('dynamic-schema-admin', plugins_url('css/dynamic-schema-admin.css', __FILE__));
    }
}
add_action('admin_enqueue_scripts', 'dynamic_schemas_enqueue_admin_css');

// ACF Fields for custom schema
function my_plugin_add_acf_field_group()
{

    if (function_exists('acf_add_local_field_group')) {
        $enabled_post_types = get_option('dynamic_schemas_custom_schema_enabled_post_types', array());

        foreach ($enabled_post_types as $post_type) {
            acf_add_local_field_group(
                array(
                    'key' => 'custom_schema_fields_' . $post_type,
                    'title' => 'Custom Schema',
                    'fields' => array(
                        array(
                            'key' => 'custom_schema_code',
                            'label' => 'Custom schema code (custom, Video, Social posting etc)',
                            'name' => 'custom_schema_code',
                            'type' => 'textarea',
                        ),
                    ),
                    'location' => array(
                        array(
                            array(
                                'param' => 'post_type',
                                'operator' => '==',
                                'value' => $post_type,
                            ),
                        ),
                    ),
                    'position' => 'normal',
                    'style' => 'default',
                    'menu_order' => 0,
                )
            );
        }
    }
}

// Hook the function to run during the ACF initialization
add_action('acf/init', 'my_plugin_add_acf_field_group');