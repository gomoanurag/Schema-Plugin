=== Dynamic Schema Generator ===
Contributors: anuragdeokar
Tags: Schema Generator, Dynamic Schema, Schema Plugin, SEO Schema Generator, Schema
Requires at least: 5.0
Tested up to: 6.3.1
Requires PHP: 7.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds organisation, news, article, blogs, product, etc schema dynamically to your website

== Description ==
This plugin generates and adds multiple types of schemas to your your website with the help of just a enable and disable button. It can add organisation, news, article, blog post, product, author, etc schema to your website dynamically.

It will also give you ability to add custom schema to any page or post type as per your needs by using the custom schema option.

Hope you like it and it will save lot of your SEO and Development time and efforts.

== Installation ==
1. Download the plugin from the wordpress plugins repository and upload on your site.
2. Activate the plugin and check the \"Dynamic Schemas\" option in your wordpress dashboard
3. Manage the schema by checking the enable/disable options and \"manage schema\" links for respective schemas\'s


== Frequently Asked Questions ==
Which other plugins do I need for this plugin to work?

You will need to install free version of ACF in order to use the \"Custom Schema Code\" functionality of this plugin. We recommend you to Install ACF free version when you install this plugin.

== Screenshots ==
1. How to enable/disable schema options
2. How to manage internal options for schema types
3. How to add custom schema option to page/post types

== Changelog ==
1.0.0 Initial Version

== Upgrade Notice ==
We will provide updates to this plugins on regular basis