<?php
// // Add website schema if enabled
// function add_website_schema_if_enabled() {
//     $website_enabled = get_option('dynamic_schemas_website_enabled', 'off');
//     if ($website_enabled === 'on') {
//         add_action('wp_head', 'add_website_schema');
//     }
// }
// add_action('wp', 'add_website_schema_if_enabled');


// Add News Article schema on blog post pages if enabled
function add_news_article_schema_if_enabled() {
    $news_enabled = get_option('dynamic_schemas_news_article_enabled', 'off');
    if ($news_enabled === 'on') {
        add_action('wp_head', 'add_news_article_schema');
    }
}
add_action('wp', 'add_news_article_schema_if_enabled');


// Add Blog Post schema on blog post pages if enabled
function add_blog_post_schema_if_enabled() {
    $blog_post_enabled = get_option('dynamic_schemas_blog_post_enabled', 'off');
    if ($blog_post_enabled === 'on') {
        add_action('wp_head', 'add_blog_post_schema');
    }
}
add_action('wp', 'add_blog_post_schema_if_enabled');



// Website Schema
// function add_website_schema() {
//     $website = array(
//         '@context' => 'https://schema.org',
//         '@type' => 'WebSite',
//         'name' => get_bloginfo('name'),
//         'url' => get_bloginfo('url'),
//     );

//     echo '<script type="application/ld+json">' . json_encode($website) . '</script>';
// }


// Add Article schema on post pages if enabled
function add_article_schema_if_enabled() {
    $article_enabled = get_option('dynamic_schemas_article_enabled', 'off');
    if ($article_enabled === 'on') {
        add_action('wp_head', 'add_article_schema');
    }
}
add_action('wp', 'add_article_schema_if_enabled');


// Add News Article schema
function add_news_article_schema() {
	
	$selected_post_type = get_option('dynamic_schemas_news_article_post_type'); // Get the selected post type

    if ( $selected_post_type && is_singular($selected_post_type)) {
        $post_id = get_the_ID();
        $post_title = get_the_title($post_id);
        $post_description = get_the_excerpt($post_id);
        $article_type = get_option('dynamic_schemas_blog_article_type', 'NewsArticle');

        $image_url = get_the_post_thumbnail_url($post_id, 'full');

        $author_name = get_the_author_meta('display_name');
        $author_url = get_author_posts_url(get_the_author_meta('ID'));

        $publisher_name = get_bloginfo('name');
        $publisher_logo = get_theme_mod('custom_logo') ? wp_get_attachment_image_src(get_theme_mod('custom_logo'))[0] : '';

        $date_published = get_the_date('c', $post_id);
        $date_modified = get_the_modified_date('c', $post_id);

        $news_article = array(
            '@context' => 'https://schema.org',
            '@type' => $article_type,
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id' => get_permalink($post_id),
            ),
            'headline' => $post_title,
            'description' => $post_description,
            'image' => $image_url,
            'author' => array(
                '@type' => 'Person',
                'name' => $author_name,
                'url' => $author_url,
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => $publisher_name,
                'logo' => array(
                    '@type' => 'ImageObject',
                    'url' => $publisher_logo,
                ),
            ),
            'datePublished' => $date_published,
            'dateModified' => $date_modified,
        );

        echo '<script type="application/ld+json">' . json_encode($news_article) . '</script>';
    }
}


// Add Blog Post schema
function add_blog_post_schema() {
    $selected_post_type = get_option('dynamic_schemas_blog_post_post_type', ''); // Get the selected post type

    if ( $selected_post_type && is_singular($selected_post_type)) {
        $post_id = get_the_ID();
        $post_title = get_the_title($post_id);
        $post_description = get_the_excerpt($post_id);
        $article_type = 'BlogPosting';

        $image_url = get_the_post_thumbnail_url($post_id, 'full');

        $author_name = get_the_author_meta('display_name');
        $author_url = get_author_posts_url(get_the_author_meta('ID'));

        $publisher_name = get_bloginfo('name');
        $publisher_logo = get_theme_mod('custom_logo') ? wp_get_attachment_image_src(get_theme_mod('custom_logo'))[0] : '';

        $date_published = get_the_date('c', $post_id);
        $date_modified = get_the_modified_date('c', $post_id);

        $blog_post = array(
            '@context' => 'https://schema.org',
            '@type' => $article_type,
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id' => get_permalink($post_id),
            ),
            'headline' => $post_title,
            'description' => $post_description,
            'image' => $image_url,
            'author' => array(
                '@type' => 'Person',
                'name' => $author_name,
                'url' => $author_url,
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => $publisher_name,
                'logo' => array(
                    '@type' => 'ImageObject',
                    'url' => $publisher_logo,
                ),
            ),
            'datePublished' => $date_published,
            'dateModified' => $date_modified,
        );

        echo '<script type="application/ld+json">' . json_encode($blog_post) . '</script>';
    }
}


// Add Article schema
function add_article_schema() {
    $selected_post_type = get_option('dynamic_schemas_article_post_type', '');

    if ( $selected_post_type && is_singular($selected_post_type)) {
        $post_id = get_the_ID();
        $post_title = get_the_title($post_id);
        $image_url = get_the_post_thumbnail_url($post_id, 'full');

        $author_name = get_the_author_meta('display_name');
        $publisher_name = get_bloginfo('name');
        $publisher_logo = get_theme_mod('custom_logo') ? wp_get_attachment_image_src(get_theme_mod('custom_logo'))[0] : '';

        $date_published = get_the_date('c', $post_id);

        $article = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => $post_title,
            'image' => $image_url,
            'author' => array(
                '@type' => 'Person',
                'name' => $author_name,
            ),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => $publisher_name,
                'logo' => array(
                    '@type' => 'ImageObject',
                    'url' => $publisher_logo,
                ),
            ),
            'datePublished' => $date_published,
        );

        echo '<script type="application/ld+json">' . json_encode($article) . '</script>';
    }
}

