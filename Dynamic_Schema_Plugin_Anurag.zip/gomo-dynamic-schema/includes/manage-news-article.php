<?php
// Render the manage NewsArticle schema page content
function dynamic_schemas_render_manage_news_article_page() {
    $selected_post_type = get_option('dynamic_schemas_news_article_post_type', ''); // Get the selected post type
    ?>
    <div class="wrap">
        <h1>Manage News Article Schema</h1>
        <form method="post" action="<?php echo admin_url('admin-post.php?action=dynamic_schemas_save_news_article_schema_settings'); ?>">
            <input type="hidden" name="action" value="dynamic_schemas_save_news_article_schema_settings">
            <?php wp_nonce_field('dynamic_schemas_news_article_settings', 'dynamic_schemas_news_article_settings_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Select Post Type:</th>
                   <td>
                        <select name="dynamic_schemas_news_article_post_type">
                            <option value="" <?php selected($selected_post_type, ''); ?>>None</option>
                            <?php
                            $post_types = get_post_types(array('public' => true), 'objects');
                            foreach ($post_types as $post_type) {
                                echo '<option value="' . esc_attr($post_type->name) . '" ' . selected($selected_post_type, $post_type->name, false) . '>' . esc_html($post_type->labels->singular_name) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// Save the NewsArticle schema settings
function dynamic_schemas_save_news_article_schema_settings() {
    if (isset($_POST['dynamic_schemas_news_article_settings_nonce']) && wp_verify_nonce($_POST['dynamic_schemas_news_article_settings_nonce'], 'dynamic_schemas_news_article_settings')) {
        $selected_post_type = sanitize_text_field($_POST['dynamic_schemas_news_article_post_type']);
        update_option('dynamic_schemas_news_article_post_type', $selected_post_type);
    }
    wp_redirect(admin_url('admin.php?page=dynamic-schemas-manage-news-article'));
    exit();
}
add_action('admin_post_dynamic_schemas_save_news_article_schema_settings', 'dynamic_schemas_save_news_article_schema_settings');
