<?php

// Render the manage product schema page content
function dynamic_schemas_render_manage_product_page() {
    $brand_name = get_option('dynamic_schemas_product_brand_name', '');
    $seller_name = get_option('dynamic_schemas_product_seller_name', '');
    ?>
    <div class="wrap">
        <h1>Manage Product Schema</h1>
        <form method="post" action="<?php echo admin_url('admin-post.php?action=dynamic_schemas_save_product_schema_settings'); ?>">
            <input type="hidden" name="action" value="dynamic_schemas_save_product_schema_settings">
            <?php wp_nonce_field('dynamic_schemas_product_settings', 'dynamic_schemas_product_settings_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Brand Name:</th>
                    <td>
                        <input type="text" name="dynamic_schemas_product_brand_name" value="<?php echo esc_attr($brand_name); ?>">
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Seller Name:</th>
                    <td>
                        <input type="text" name="dynamic_schemas_product_seller_name" value="<?php echo esc_attr($seller_name); ?>">
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// Save the product schema settings
function dynamic_schemas_save_product_schema_settings() {
    if (isset($_POST['dynamic_schemas_product_settings_nonce']) && wp_verify_nonce($_POST['dynamic_schemas_product_settings_nonce'], 'dynamic_schemas_product_settings')) {
        if (isset($_POST['dynamic_schemas_product_brand_name'])) {
            $brand_name = sanitize_text_field($_POST['dynamic_schemas_product_brand_name']);
            update_option('dynamic_schemas_product_brand_name', $brand_name);
        }

        if (isset($_POST['dynamic_schemas_product_seller_name'])) {
            $seller_name = sanitize_text_field($_POST['dynamic_schemas_product_seller_name']);
            update_option('dynamic_schemas_product_seller_name', $seller_name);
        }
    }
    wp_redirect(admin_url('admin.php?page=dynamic-schemas-manage-product'));
    exit();
}
add_action('admin_post_dynamic_schemas_save_product_schema_settings', 'dynamic_schemas_save_product_schema_settings');
