<?php
// Render the manage organization schema page content
function dynamic_schemas_render_manage_organization_page() {
    $logo_url = get_option('dynamic_schemas_organization_logo', '');
    $organization_type = get_option('dynamic_schemas_organization_type', ''); // Fetch the organization type
    $social_media_links = get_option('dynamic_schemas_organization_social_media_links', '');
    $organization_description = get_option('dynamic_schemas_organization_description', ''); // Fetch the organization description

    $organization_types = array(
        'Organization', // Default organization type
        'NGO',
        'Corporation',
        'GovernmentOrganization',
        'Airline',
		'Consortium',
		'Corporation',
		'EducationalOrganization',
		'FundingScheme',
		'GovernmentOrganization',
		'LibrarySystem',
		'LocalBusiness',
		'MedicalOrganization',
		'NGO',
		'NewsMediaOrganization',
		'OnlineBusiness',
		'PerformingGroup',
		'PoliticalParty',
		'Project',
		'ResearchOrganization',
		'SearchRescueOrganization',
		'SportsOrganization',
		'WorkersUnion',
    );
    ?>
    <div class="wrap">
        <h1>Manage Organization Schema</h1>
        <form method="post" action="<?php echo admin_url('admin-post.php?action=dynamic_schemas_save_organization_schema_settings'); ?>">
            <?php wp_nonce_field('dynamic_schemas_organization_settings', 'dynamic_schemas_organization_settings_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Logo Media Link:</th>
                    <td>
                        <input type="text" name="dynamic_schemas_organization_logo" value="<?php echo esc_attr($logo_url); ?>">
                        <input type="button" class="button button-primary" value="Select Logo" onclick="selectLogo()">
                        <script>
                            function selectLogo() {
                                wp.media.editor.send.attachment = function(props, attachment) {
                                    jQuery('input[name=dynamic_schemas_organization_logo]').val(attachment.url);
                                };
                                wp.media.editor.open();
                                return false;
                            }
                        </script>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Organization Type:</th>
                    <td>
                        <select name="dynamic_schemas_organization_type">
                            <?php
                            foreach ($organization_types as $type) {
                                echo '<option value="' . esc_attr($type) . '" ' . selected($type, $organization_type, false) . '>' . esc_html($type) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
				 <tr valign="top">
                    <th scope="row">Social Media Links:</th>
                    <td>
                        <textarea name="dynamic_schemas_organization_social_media_links" rows="5"><?php echo esc_textarea($social_media_links); ?></textarea>
                    </td>
                </tr>
				<tr valign="top">
                    <th scope="row">Organization Description:</th>
                    <td>
                        <textarea name="dynamic_schemas_organization_description" rows="5"><?php echo esc_textarea($organization_description); ?></textarea>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <?php
}

// Save the organization schema settings
function dynamic_schemas_save_organization_schema_settings() {
    if (isset($_POST['dynamic_schemas_organization_settings_nonce']) && wp_verify_nonce($_POST['dynamic_schemas_organization_settings_nonce'], 'dynamic_schemas_organization_settings')) {
        if (isset($_POST['dynamic_schemas_organization_logo'])) {
            $logo_url = sanitize_text_field($_POST['dynamic_schemas_organization_logo']);
            update_option('dynamic_schemas_organization_logo', $logo_url);
        }

        if (isset($_POST['dynamic_schemas_organization_type'])) {
            $organization_type = sanitize_text_field($_POST['dynamic_schemas_organization_type']);
            update_option('dynamic_schemas_organization_type', $organization_type); // Save the organization type
        }

        if (isset($_POST['dynamic_schemas_organization_social_media_links'])) {
            $social_media_links = sanitize_textarea_field($_POST['dynamic_schemas_organization_social_media_links']);
            update_option('dynamic_schemas_organization_social_media_links', $social_media_links); // Save the social media links
        }

        if (isset($_POST['dynamic_schemas_organization_description'])) {
            $organization_description = sanitize_textarea_field($_POST['dynamic_schemas_organization_description']);
            update_option('dynamic_schemas_organization_description', $organization_description); // Save the organization description
        }
    }

    wp_redirect(admin_url('admin.php?page=dynamic-schemas-manage-organization'));
    exit();
}
add_action('admin_post_dynamic_schemas_save_organization_schema_settings', 'dynamic_schemas_save_organization_schema_settings');
