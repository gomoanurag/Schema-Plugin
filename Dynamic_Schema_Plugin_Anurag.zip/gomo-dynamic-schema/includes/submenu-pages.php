<?php
// Add internal submenu pages for Dynamic Schema plugin
function dynamic_schemas_add_internal_submenu_pages() {
    add_submenu_page(
        'dynamic-schemas',  // Parent menu slug
        'Manage Organization Schema',  // Page title
        'Manage Organization',  // Menu title
        'manage_options',  // Capability required
        'dynamic-schemas-manage-organization',  // Menu slug
        'dynamic_schemas_render_manage_organization_page'  // Callback function to render the page content
    );
	
	
    add_submenu_page(
        'dynamic-schemas',  // Parent menu slug
        'Manage Product Schema',  // Page title
        'Manage Product',  // Menu title
        'manage_options',  // Capability required
        'dynamic-schemas-manage-product',  // Menu slug
        'dynamic_schemas_render_manage_product_page'  // Callback function to render the page content
    );

//     add_submenu_page(
//         'dynamic-schemas',  // Parent menu slug
//         'Manage Website Schema',  // Page title
//         'Manage Website',  // Menu title
//         'manage_options',  // Capability required
//         'dynamic-schemas-manage-website',  // Menu slug
//         'dynamic_schemas_render_manage_website_page'  // Callback function to render the page content
//     );

    add_submenu_page(
        'dynamic-schemas',  // Parent menu slug
        'Manage News Article Schema',  // Page title
        'Manage News Article',  // Menu title
        'manage_options',  // Capability required
        'dynamic-schemas-manage-news-article',  // Menu slug
        'dynamic_schemas_render_manage_news_article_page'  // Callback function to render the page content
    );

    add_submenu_page(
        'dynamic-schemas',  // Parent menu slug
        'Manage Article Schema',  // Page title
        'Manage Article',  // Menu title
        'manage_options',  // Capability required
        'dynamic-schemas-manage-article',  // Menu slug
        'dynamic_schemas_render_manage_article_page'  // Callback function to render the page content
    );
   

    add_submenu_page(
        'dynamic-schemas',  // Parent menu slug
        'Manage Blog Posts',  // Page title
        'Manage Blog Post',  // Menu title
        'manage_options',  // Capability required
        'dynamic-schemas-manage-blog-post',  // Menu slug
        'dynamic_schemas_render_manage_blog_post_page'  // Callback function to render the page content
    );
	
	
    add_submenu_page(
    'dynamic-schemas',  // Parent menu slug
    'Manage Custom Schema',  // Page title
    'Manage Custom Schema',  // Menu title
    'manage_options',  // Capability required
    'dynamic-schemas-manage-custom-schema',  // Menu slug
    'dynamic_schemas_render_manage_custom_schema_page'  // Callback function to render the page content
    );

    // Add submenu pages for other schema options similarly
}
add_action('admin_menu', 'dynamic_schemas_add_internal_submenu_pages');

