<?php
// Submenu page for custom Schema
function dynamic_schemas_render_manage_custom_schema_page() {
    // Update ACF fields based on enabled post types
    if (isset($_POST['submit'])) {
        $enabled_post_types = isset($_POST['dynamic_schemas_custom_schema_enabled_post_types']) ? $_POST['dynamic_schemas_custom_schema_enabled_post_types'] : array();
        update_option('dynamic_schemas_custom_schema_enabled_post_types', $enabled_post_types);
        my_plugin_add_acf_field_group(); // Add/update ACF fields based on the new settings
    }

    ?>
    <div class="wrap">
        <h1>Manage Custom Schema</h1>
        <form method="post" action="">
            <?php
            settings_fields('dynamic-schemas');
            do_settings_sections('dynamic-schemas');
            ?>
            <h2>Enable Custom Schema</h2>
            <?php
            $enabled_post_types = get_option('dynamic_schemas_custom_schema_enabled_post_types', array());
            $post_types = get_post_types(array('public' => true), 'names');
            foreach ($post_types as $post_type) {
                ?>
                <label>
                    <input type="checkbox" name="dynamic_schemas_custom_schema_enabled_post_types[]" value="<?php echo $post_type; ?>" <?php checked(in_array($post_type, $enabled_post_types)); ?>>
                    <?php echo ucfirst($post_type); ?>
                </label><br>
                <?php
            }
            ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function add_custom_schema_if_enabled() {
    $custom_enabled = get_option('dynamic_schemas_custom_schema_enabled', 'off');
    if ($custom_enabled === 'on') {
        add_action('wp_head', 'add_custom_schema_to_head');
    }
}
add_action('wp', 'add_custom_schema_if_enabled');

// function add_custom_schema_to_head() {
//     if (is_singular()) {
//         global $post;
//         $enabled_post_types = get_option('dynamic_schemas_custom_schema_enabled_post_types', array());
//         $current_post_type = $post->post_type;

//         if (in_array($current_post_type, $enabled_post_types)) {
//             $schema_data = get_field('custom_schema_code', $post->ID);
//             if ($schema_data) {
//                 echo '<script type="application/ld+json">';
//                 echo ($schema_data);
//                 echo '</script>';
//             }
//         }
//     }
// }

function add_custom_schema_to_head() {
    if (is_singular()) {
        global $post;
        $enabled_post_types = get_option('dynamic_schemas_custom_schema_enabled_post_types', array());
        $current_post_type = $post->post_type;

        if (in_array($current_post_type, $enabled_post_types)) {
            // Check if ACF functions exist
            if (function_exists('get_field')) {
                $schema_data = get_field('custom_schema_code', $post->ID);
                if ($schema_data) {
                    echo '<script type="application/ld+json">';
                    echo ($schema_data);
                    echo '</script>';
                }
            }
        }
    }
}