<?php
// Add settings page to the dashboard menu
function dynamic_schemas_settings_page() {
    add_menu_page(
        'Dynamic Schemas Settings',
        'Dynamic Schemas',
        'manage_options',
        'dynamic-schemas',
        'dynamic_schemas_render_settings',
        'dashicons-admin-settings',
        85
    );
}
add_action('admin_menu', 'dynamic_schemas_settings_page');

// Render settings page
function dynamic_schemas_render_settings() {
    ?>
    <div class="wrap">
        <h1>Dynamic Schemas Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('dynamic-schemas');
            do_settings_sections('dynamic-schemas');
            ?>
            <h2>Enable Schemas</h2>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Organization Schema:</th>
                    <td>
                        <label for="dynamic_schemas_organization_enabled">
                            <input type="checkbox" id="dynamic_schemas_organization_enabled" name="dynamic_schemas_organization_enabled" <?php checked(get_option('dynamic_schemas_organization_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
						<a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-organization'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Product Schema:</th>
                    <td>
                        <label for="dynamic_schemas_product_enabled">
                            <input type="checkbox" id="dynamic_schemas_product_enabled" name="dynamic_schemas_product_enabled" <?php checked(get_option('dynamic_schemas_product_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                        <a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-product'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr>
<!--                 <tr valign="top">
                    <th scope="row">Website Schema:</th>
                    <td>
                        <label for="dynamic_schemas_website_enabled">
                            <input type="checkbox" id="dynamic_schemas_website_enabled" name="dynamic_schemas_website_enabled" <?php checked(get_option('dynamic_schemas_website_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                        <a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-website'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr> -->
                <tr valign="top">
                    <th scope="row">News Article Schema:</th>
                    <td>
                        <label for="dynamic_schemas_news_article_enabled">
                            <input type="checkbox" id="dynamic_schemas_news_article_enabled" name="dynamic_schemas_news_article_enabled" <?php checked(get_option('dynamic_schemas_news_article_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                        <a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-news-article'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Article Schema:</th>
                    <td>
                        <label for="dynamic_schemas_article_enabled">
                            <input type="checkbox" id="dynamic_schemas_article_enabled" name="dynamic_schemas_article_enabled" <?php checked(get_option('dynamic_schemas_article_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                        <a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-article'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Blog Post Schema:</th>
                    <td>
                        <label for="dynamic_schemas_blog_post_enabled">
                            <input type="checkbox" id="dynamic_schemas_blog_post_enabled" name="dynamic_schemas_blog_post_enabled" <?php checked(get_option('dynamic_schemas_blog_post_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                        <a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-blog-post'); ?>" class="button button-primary">Manage Schema</a>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Custom Schema:</th>
                    <td>
                        <label for="dynamic_schemas_custom_schema_enabled">
                            <input type="checkbox" id="dynamic_schemas_custom_schema_enabled" name="dynamic_schemas_custom_schema_enabled" <?php checked(get_option('dynamic_schemas_custom_schema_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
						<a href="<?php echo admin_url('admin.php?page=dynamic-schemas-manage-custom-schema'); ?>" class="button button-primary">Manage Schema</a>

                    </td>
                </tr>
				  <tr valign="top">
                    <th scope="row">Author Schema:</th>
                    <td>
                        <label for="dynamic_schemas_author_enabled">
                            <input type="checkbox" id="dynamic_schemas_author_enabled" name="dynamic_schemas_author_enabled"
                                <?php checked(get_option('dynamic_schemas_author_enabled', 'off'), 'on'); ?>>
                            Enable
                        </label>
                    </td>
                </tr>
            </table>
            <div style="display: inline-flex; gap: 30px; justify-content: center; align-items: center;"> 
			   <?php 
				submit_button(); 
			   ?> 
			   <a href="https://validator.schema.org/" style="margin-top:5px; background-color:#990000; border:0px;" class="button button-primary" target="_blank">Check in schema validator</a> 
			</div>
        </form>
    </div>
    <?php
}

// Register and sanitize settings
function dynamic_schemas_register_settings() {
    register_setting('dynamic-schemas', 'dynamic_schemas_organization_enabled', 'sanitize_text_field');
    register_setting('dynamic-schemas', 'dynamic_schemas_product_enabled', 'sanitize_text_field');
//     register_setting('dynamic-schemas', 'dynamic_schemas_website_enabled', 'sanitize_text_field');
    register_setting('dynamic-schemas', 'dynamic_schemas_news_article_enabled', 'sanitize_text_field');
    register_setting('dynamic-schemas', 'dynamic_schemas_author_enabled', 'sanitize_text_field');
    register_setting('dynamic-schemas', 'dynamic_schemas_article_enabled', 'sanitize_text_field');
	register_setting('dynamic-schemas', 'dynamic_schemas_custom_schema_enabled', 'sanitize_text_field');
    register_setting('dynamic-schemas', 'dynamic_schemas_blog_post_enabled', 'sanitize_text_field');
}
add_action('admin_init', 'dynamic_schemas_register_settings');

// Sanitize the enabled post types for custom Schema
function dynamic_schemas_sanitize_post_types($input) {
    if (!is_array($input)) {
        return array();
    }

    return array_map('sanitize_text_field', $input);
}
