<?php
// Add organization schema if enabled
function add_organization_schema_if_enabled() {
    $organization_enabled = get_option('dynamic_schemas_organization_enabled', 'off');
    if ($organization_enabled === 'on') {
        add_action('wp_head', 'add_organization_schema');
    }
}
add_action('wp', 'add_organization_schema_if_enabled');


// Add product schema if enabled
function add_product_schema_if_enabled() {
    $product_enabled = get_option('dynamic_schemas_product_enabled', 'off');
    if ($product_enabled === 'on') {
        add_action('wp_head', 'add_product_schema');
    }
}
add_action('wp', 'add_product_schema_if_enabled');


// Add author schema if enabled
function add_author_schema_if_enabled() {
    $author_enabled = get_option('dynamic_schemas_author_enabled', 'off');
    if ($author_enabled === 'on') {
        add_action('wp_head', 'add_author_schema');
    }
}
add_action('wp', 'add_author_schema_if_enabled');

// Organization Schema
function add_organization_schema() {
    $organization_type = get_option('dynamic_schemas_organization_type', 'Organization'); // Default organization type

    $organization = array(
        '@context' => 'https://schema.org',
        '@type' => $organization_type, // Use the selected organization type
        'name' => get_bloginfo('name'),
        'url' => get_bloginfo('url'),
        'logo' => get_option('dynamic_schemas_organization_logo', ''),
    );

    // Add organization description
    $organization_description = get_option('dynamic_schemas_organization_description', '');
    if (!empty($organization_description)) {
        $organization['description'] = $organization_description;
    }

    // Add social media links
    $social_media_links = get_option('dynamic_schemas_organization_social_media_links', '');
    if (!empty($social_media_links)) {
        $links = explode("\n", $social_media_links);
        $links = array_map('trim', $links);

        foreach ($links as $link) {
            if (!empty($link)) {
                $organization['sameAs'][] = $link;
            }
        }
    }

    echo '<script type="application/ld+json">' . json_encode($organization) . '</script>';
}




// Product Schema
function add_product_schema() {
    if (is_singular('product')) { 
        $product_id = get_the_ID();
        $availability = '';

        // Get the product availability based on WooCommerce settings
        $stock_status = get_post_meta($product_id, '_stock_status', true);
        if ($stock_status === 'instock') {
            $availability = 'InStock';
        } elseif ($stock_status === 'outofstock') {
            $availability = 'OutOfStock';
        }

        $product = array(
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => get_the_title($product_id),
            'url' => get_permalink($product_id),
            'image' => get_the_post_thumbnail_url($product_id, 'full'),
            'description' => get_the_excerpt($product_id),
            'brand' => array(
                '@type' => 'Organization',
                'name' => get_option('dynamic_schemas_product_brand_name', 'Your Brand Name'),
            ),
            'offers' => array(
                '@type' => 'Offer',
                'priceCurrency' => get_woocommerce_currency(),
                'price' => wc_get_product($product_id)->get_regular_price(), 
                'availability' => $availability,
                'seller' => array(
                    '@type' => 'Organization',
                    'name' => get_option('dynamic_schemas_product_seller_name', 'Your Organization Name'),
                ),
            ),
        );

        echo '<script type="application/ld+json">' . json_encode($product) . '</script>';
    }
}
// Add Author schema
function add_author_schema() {
    $user_id = get_current_user_id();

    // Get the user data
    $user_data = get_userdata($user_id);

    $author_name = get_the_author_meta('display_name', $user_id);
    $author_url = get_author_posts_url($user_id);
    $author_image = get_user_meta($user_id, '_profile_picture', true); // Corrected user meta key

    // Get organization/ author details
    $organization_name = get_option('dynamic_schemas_organization_name');
    $organization_url = get_option('dynamic_schemas_organization_url');
    $organization_logo = get_option('dynamic_schemas_organization_logo');
    $author_bio = get_the_author_meta('description', $user_id);
	$author_phone = get_the_author_meta('phone', $user_id);
    $author_linkedin = get_the_author_meta('linkedin', $user_id);
    $author_facebook = get_the_author_meta('facebook', $user_id);
    $author_instagram = get_the_author_meta('instagram', $user_id);
    $author_youtube = get_the_author_meta('youtube', $user_id);
    $author_email = get_the_author_meta('user_email', $user_id);

    $author = array(
        '@context' => 'https://schema.org',
        '@type' => 'Person',
        'name' => $author_name,
        'url' => $author_url,
		'description' => $author_bio,
		'telephone' => $author_phone,
        'sameAs' => array( 
            $author_linkedin,
            $author_facebook,
            $author_instagram,
            $author_youtube,
        ),
        'email' => $author_email,
    );

    if (!empty($author_image)) {
        $author['image'] = $author_image;
    }

    // Add organization details
    $organization = array(
        '@type' => 'Organization',
        'name' => get_bloginfo('name'),
        'url' => get_bloginfo('url'),
        'logo' => get_option('dynamic_schemas_organization_logo', ''),
    );

    if (!empty($organization_logo)) {
        $organization['logo'] = $organization_logo;
    }

    // Add organization to author schema
    $author['memberOf'] = $organization;

    echo '<script type="application/ld+json">' . json_encode($author) . '</script>';
}


